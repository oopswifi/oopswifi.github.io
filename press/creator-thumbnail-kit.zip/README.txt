主播封面素材包 · 糟了！我只是来恋综修网线的

一分钟拼一张视频封面：backdrops 里选一张背景（右边留给你的头像框和大标题），cutouts 里放一两位女嘉宾，
再从 overlays 里加「翻车现场」印章、REC 镜头框、心动和节目热度的提示条、8 秒倒计时或游戏标题。
16x9 是 1920×1080（YouTube、B 站电脑端），4x3 是 1200×900（B 站手机端信息流）。

画面由 AI 生成 · 所有角色均为成年人，剧情纯属虚构。素材只用了免费试玩部分（序章和第一集）的画面。
欢迎直播、录视频、截图和做切片，包括带收益的视频，任何章节都可以。附上免费试玩链接就更好了；如果方便，请别在标题和封面里剧透隐藏路线。请勿转载或再分发游戏文件和剧本文字，也请勿公开激活码。游戏的音乐和音效都由程序实时合成，没有版权音乐，不会因为配乐被静音或下架。

Streamer thumbnail kit: backdrops (the right side is free for a facecam and a title), five transparent cut-outs, and
transparent overlays (the 翻车现场 stamp, a REC frame, toasts, an 8-second countdown, the title in Simplified,
Traditional and English). Free-demo pictures only. The images are AI-generated; all characters are fictional adults.
Videos, streams, screenshots and clips of any part of the game are welcome, monetised ones included, and a link to the free demo is appreciated (if you can, keep the hidden route out of titles and thumbnails). Please don't re-upload the game files or the script, or post activation codes. All music and sound effects are synthesized by the game itself: no licensed music, so no copyright mutes or claims.
